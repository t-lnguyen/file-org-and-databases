# ************************************************************
# Sequel Ace SQL dump
# Version 20016
#
# https://sequel-ace.com/
# https://github.com/Sequel-Ace/Sequel-Ace
#
# Host: localhost (MySQL 8.0.27)
# Database: CS7330_Project
# Generation Time: 2021-12-02 21:12:37 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE='NO_AUTO_VALUE_ON_ZERO', SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table Builder
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Builder`;

CREATE TABLE `Builder` (
  `LicenseID` int NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `InspectionOrderID` int DEFAULT NULL,
  PRIMARY KEY (`LicenseID`),
  KEY `InspectionOrderID` (`InspectionOrderID`),
  CONSTRAINT `builder_ibfk_1` FOREIGN KEY (`InspectionOrderID`) REFERENCES `Inspection` (`InspectionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `Builder` WRITE;
/*!40000 ALTER TABLE `Builder` DISABLE KEYS */;

INSERT INTO `Builder` (`LicenseID`, `Name`, `Address`, `InspectionOrderID`)
VALUES
	(12321,'Builder-5','12321 Builder Circle, Dallas TX',NULL),
	(12345,'Builder-1','12345 Builder Circle, Dallas TX',NULL),
	(23456,'Builder-2','23456 Builder Circle, Dallas TX',NULL),
	(34567,'Builder-3','34567 Builder Circle, Dallas TX',NULL),
	(45678,'Builder-4','45678 Builder Circle, Dallas TX',NULL);

/*!40000 ALTER TABLE `Builder` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Building
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Building`;

CREATE TABLE `Building` (
  `BuilderID` int NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `Size` int DEFAULT NULL,
  `DateFirstActivity` date DEFAULT NULL,
  `InspectionRecordID` int DEFAULT NULL,
  PRIMARY KEY (`Address`),
  KEY `BuilderID` (`BuilderID`),
  KEY `InspectionRecordID` (`InspectionRecordID`),
  CONSTRAINT `building_ibfk_1` FOREIGN KEY (`BuilderID`) REFERENCES `Builder` (`LicenseID`),
  CONSTRAINT `building_ibfk_2` FOREIGN KEY (`InspectionRecordID`) REFERENCES `Inspection` (`InspectionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;

INSERT INTO `Building` (`BuilderID`, `Address`, `Type`, `Size`, `DateFirstActivity`, `InspectionRecordID`)
VALUES
	(23456,'100 Industrial Ave., Fort Worth, TX','commerical',100000,'2005-06-01',NULL),
	(12345,'100 Main St., Dallas, TX','commerical',250000,'1999-12-31',NULL),
	(45678,'100 Winding Wood, Carrollton, TX','residential',2500,NULL,NULL),
	(23456,'101 Industrial Ave., Fort Worth, TX','commerical',80000,'2005-06-01',NULL),
	(23456,'102 Industrial Ave., Fort Worth, TX','commerical',75000,'2005-06-01',NULL),
	(45678,'102 Winding Wood, Carrollton, TX','residential',2800,NULL,NULL),
	(23456,'103 Industrial Ave., Fort Worth, TX','commerical',50000,'2005-06-01',NULL),
	(23456,'104 Industrial Ave., Fort Worth, TX','commerical',80000,'2005-06-01',NULL),
	(23456,'105 Industrial Ave., Fort Worth, TX','commerical',90000,'2005-06-01',NULL),
	(34567,'1420 Main St., Lewisville TX','residential',1600,NULL,NULL),
	(12321,'210 Cherry Bark Lane, Plano, TX','residential',3200,'2016-10-01',NULL),
	(12321,'212 Cherry Bark Lane, Plano, TX','residential',NULL,NULL,NULL),
	(12321,'214 Cherry Bark Lane, Plano, TX','residential',NULL,NULL,NULL),
	(12321,'216 Cherry Bark Lane, Plano, TX','residential',NULL,NULL,NULL),
	(12345,'300 Oak St., Dallas, TX','residential',3000,'2000-01-01',NULL),
	(12345,'302 Oak St., Dallas, TX','residential',4000,'2001-02-01',NULL),
	(12345,'304 Oak St., Dallas, TX','residential',1500,'2002-03-01',NULL),
	(12345,'306 Oak St., Dallas, TX','residential',1500,'2003-04-01',NULL),
	(12345,'308 Oak St., Dallas, TX','residential',2000,'2003-04-01',NULL);

/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Inspection
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Inspection`;

CREATE TABLE `Inspection` (
  `InspectionID` int NOT NULL,
  `Type` varchar(3) NOT NULL,
  `InspectionDate` date NOT NULL,
  `LicenseID` int DEFAULT NULL,
  `EmployeeID` int DEFAULT NULL,
  `Cost` int NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Score` int NOT NULL,
  `Details` varchar(200) NOT NULL,
  `InspectionResults` int NOT NULL,
  PRIMARY KEY (`InspectionID`),
  KEY `LicenseID` (`LicenseID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `Address` (`Address`),
  CONSTRAINT `inspection_ibfk_1` FOREIGN KEY (`LicenseID`) REFERENCES `Builder` (`LicenseID`),
  CONSTRAINT `inspection_ibfk_2` FOREIGN KEY (`EmployeeID`) REFERENCES `Inspector` (`EmployeeID`),
  CONSTRAINT `inspection_ibfk_3` FOREIGN KEY (`Address`) REFERENCES `Building` (`Address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `Inspection` WRITE;
/*!40000 ALTER TABLE `Inspection` DISABLE KEYS */;

INSERT INTO `Inspection` (`InspectionID`, `Type`, `InspectionDate`, `LicenseID`, `EmployeeID`, `Cost`, `Address`, `Score`, `Details`, `InspectionResults`)
VALUES
	(1,'FRM','2021-10-01',12345,101,100,'300 Oak St., Dallas, TX',100,'no problems noted',1),
	(2,'PLU','2021-10-02',12345,101,100,'300 Oak St., Dallas, TX',90,'minor leak, corrected',1),
	(3,'ELE','2021-10-03',12345,101,100,'300 Oak St., Dallas, TX',80,'exposed junction box',1),
	(4,'HAC','2021-10-04',12345,101,100,'300 Oak St., Dallas, TX',80,'duct needs taping',1),
	(5,'FNL','2021-10-05',12345,101,200,'300 Oak St., Dallas, TX',90,'ready for owner',1),
	(6,'FRM','2021-10-01',12345,102,100,'302 Oak St., Dallas, TX',100,'no problems noted',1),
	(7,'PLU','2021-10-02',12345,102,100,'302 Oak St., Dallas, TX',25,'massive leaks',0),
	(8,'PLU','2021-10-08',12345,102,100,'302 Oak St., Dallas, TX',50,'still leaking',0),
	(9,'PLU','2021-10-12',12345,102,100,'302 Oak St., Dallas, TX',80,'no leaks, but messy',1),
	(10,'ELE','2021-10-14',12345,102,100,'302 Oak St., Dallas, TX',100,'no problems noted',1),
	(11,'HAC','2021-11-01',12345,102,100,'302 Oak St., Dallas, TX',80,'duct needs taping',1),
	(12,'FNL','2021-11-02',12345,102,200,'302 Oak St., Dallas, TX',90,'ready for owner',1),
	(13,'FRM','2021-10-01',45678,103,100,'100 Winding Wood, Carrollton, TX',100,'no problems noted',1),
	(14,'PLU','2021-10-20',45678,103,100,'100 Winding Wood, Carrollton, TX',100,'everything working',1),
	(15,'ELE','2021-10-25',45678,103,100,'100 Winding Wood, Carrollton, TX',100,'no problems noted',1),
	(16,'HAC','2021-11-02',45678,103,100,'100 Winding Wood, Carrollton, TX',100,'no problems noted',1),
	(17,'FNL','2021-11-14',45678,103,200,'100 Winding Wood, Carrollton, TX',100,'REJECT TOO MANY',1),
	(19,'PLU','2021-11-02',45678,103,100,'102 Winding Wood, Carrollton, TX',90,'minor leak, corrected',1),
	(20,'ELE','2021-11-03',45678,103,100,'102 Winding Wood, Carrollton, TX',80,'nexposed junction box',1),
	(21,'FRM','2021-10-12',12321,103,100,'210 Cherry Bark Lane, Plano, TX',85,'no issues but messy',1),
	(22,'PLU','2021-11-04',12321,103,100,'210 Cherry Bark Lane, Plano, TX',80,'duct needs sealing',1),
	(23,'SAF','2021-10-14',12321,104,50,'210 Cherry Bark Lane, Plano, TX',100,'no problems noted',1),
	(24,'FRM','2021-11-06',23456,105,100,'100 Industrial Ave., Fort Worth, TX',100,'okay',1),
	(25,'FRM','2021-11-02',23456,105,100,'105 Industrial Ave., Fort Worth, TX',100,'all work completed per checklist.',1),
	(26,'POL','2021-11-05',12321,105,90,'210 Cherry Bark Lane, Plano, TX',100,'ready for owner',1),
	(27,'FRM','2021-11-21',34567,104,100,'1420 Main St., Lewisville TX',50,'work not finished.',0),
	(28,'FRM','2021-11-22',34567,104,150,'1420 Main St., Lewisville TX',60,'lights not completed.',0),
	(29,'POL','2021-11-28',45678,103,50,'100 Winding Wood, Carrollton, TX',76,'Dirty filter',1);

/*!40000 ALTER TABLE `Inspection` ENABLE KEYS */;
UNLOCK TABLES;

DELIMITER ;;
/*!50003 SET SESSION SQL_MODE="ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION" */;;
/*!50003 CREATE */ /*!50017 DEFINER=`root`@`localhost` */ /*!50003 TRIGGER `enforce_Inspection_request_limit` BEFORE INSERT ON `Inspection` FOR EACH ROW BEGIN
	-- If an Inspector.EmployeeID already has 5 Inspections.InspectionID assigned, of which are all contained in a month,
    -- assumming they pass the sequencing requirements, then the NEW.InspectionID cannot be inserted
    IF((select COUNT(*) from Inspection i where i.EmployeeID = NEW.EmployeeID AND month(i.InspectionDate) = month(NEW.InspectionDate)) > 5) THEN
			signal sqlstate '45000' set message_text = 'Max Inspection Requests for an Inspector are 5 max per month!';	
        END IF;
END */;;
/*!50003 SET SESSION SQL_MODE="ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION" */;;
/*!50003 CREATE */ /*!50017 DEFINER=`root`@`localhost` */ /*!50003 TRIGGER `enforce_Builder_Building_existent_before_inspection_rq` BEFORE INSERT ON `Inspection` FOR EACH ROW BEGIN
    IF(NOT EXISTS(select b.* from Builder b join Building b1 on b.LicenseID = b1.BuilderID where b.LicenseID = NEW.LicenseID AND b1.Address IS NOT NULL)) THEN
            signal sqlstate '45005' set message_text = 'Builder or Building must exist before requesting an Inspection!';  
        END IF;
END */;;
/*!50003 SET SESSION SQL_MODE="ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION" */;;
/*!50003 CREATE */ /*!50017 DEFINER=`root`@`localhost` */ /*!50003 TRIGGER `enforce_Inspection_Type_sequence_and_pass_status` BEFORE INSERT ON `Inspection` FOR EACH ROW BEGIN
	-- If Inspection.Type is PLU OR ELE AND the assigned Inspector.Address does not have a Inspection.Type = FRM and of this, a passing Inspection Inspection.InspectionResult = 1,
    -- then it cannot be inserted
    IF((NEW.Type = 'PLU' OR NEW.Type = 'ELE') AND 
		NOT EXISTS(select i.InspectionDate from Inspection i where i.Address = NEW.Address AND i.Type = 'FRM' AND i.InspectionResults = 1))
		THEN
		signal sqlstate '45010' set message_text = 'Inspection Type PLU or ELE does not have passing FRM!';	
    END IF;
    
    -- If Inspection.Type is FN3 OR POL AND the assigned Inspector.EmployeeID does not have a Inspection.Type = PLU and Inspection.InspectionResult = Pass,
    -- then it cannot be inserted
      IF((NEW.Type = 'FN3' OR NEW.Type = 'POL') AND 
		NOT EXISTS(select i.InspectionDate from Inspection i where i.Address = NEW.Address AND i.Type = 'PLU' AND i.InspectionResults = 1)) 
		THEN
		signal sqlstate '45011' set message_text = 'Inspection Type FN3 or POL does not have passing PLU!';	
    END IF;
    
    -- If Inspection.Type is HAC AND the assigned Inspector.EmployeeID does not have a Inspection.Type = ELE and Inspection.InspectionResult = Pass,
    -- then it cannot be inserted
    IF((NEW.Type = 'HAC') AND 
		NOT EXISTS(select i.InspectionDate from Inspection i where i.Address = NEW.Address AND i.Type = 'ELE' AND i.InspectionResults = 1)) 
		THEN
		signal sqlstate '45012' set message_text = 'Inspection Type HAC does not have passing ELE!';	
    END IF;   
      -- If Inspection.Type is FNL AND the assigned Inspector.EmployeeID does not have a Inspection.Type = HAC AND Inspection.Type = PLU AND Inspection.InspectionResult = Pass for both,
    -- then it cannot be inserted
    IF((NEW.Type = 'FNL') AND 
		NOT EXISTS(select i.InspectionDate from Inspection i where i.Address = NEW.Address AND i.Type = 'HAC' AND i.InspectionResults = 1) AND 
		NOT EXISTS(select i.InspectionDate from Inspection i where i.Address = NEW.Address AND i.Type = 'PLU' AND i.InspectionResults = 1)) THEN
			signal sqlstate '45013' set message_text = 'Inspection Type FNL does not have passing HAC AND PLU!';	
    END IF;
	-- If Inspection.Type is FN2 AND the assigned Inspector.EmployeeID does not have a Inspection.Type = ELE AND Inspection.Type = PLU AND Inspection.InspectionResult = Pass for both,
    -- then it cannot be inserted
    IF((NEW.Type = 'FN2')AND 
		NOT EXISTS(select i.InspectionDate from Inspection i where i.Address = NEW.Address AND i.Type = 'ELE' AND i.InspectionResults = 1) AND 
		NOT EXISTS(select i.InspectionDate from Inspection i where i.Address = NEW.Address AND i.Type = 'PLU' AND i.InspectionResults = 1)) THEN
			signal sqlstate '45014' set message_text = 'Inspection Type FN2 does not have passing ELE AND PLU!';	
    END IF;
 
END */;;
DELIMITER ;
/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE */;


# Dump of table Inspector
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Inspector`;

CREATE TABLE `Inspector` (
  `EmployeeID` int NOT NULL,
  `Name` varchar(30) NOT NULL,
  `HireDate` date NOT NULL,
  PRIMARY KEY (`EmployeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

LOCK TABLES `Inspector` WRITE;
/*!40000 ALTER TABLE `Inspector` DISABLE KEYS */;

INSERT INTO `Inspector` (`EmployeeID`, `Name`, `HireDate`)
VALUES
	(101,'Inspector-1','1984-11-08'),
	(102,'Inspector-2','1994-11-08'),
	(103,'Inspector-3','2004-11-08'),
	(104,'Inspector-4','2014-11-08'),
	(105,'Inspector-5','2018-11-08');

/*!40000 ALTER TABLE `Inspector` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
